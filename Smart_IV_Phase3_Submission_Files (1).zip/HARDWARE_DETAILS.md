# Hardware Details — Smart IV Monitoring System

> Fill this file using the hardware that is physically present in your current prototype. Do not guess part numbers or mark planned components as implemented.

## 1. Bill of materials

| Item | Exact manufacturer/model | Quantity | Operating voltage | Role | Status (implemented/planned) |
|---|---|---:|---|---|---|
| Main microcontroller | [Enter exact board/model] | [ ] | [ ] | Sensor acquisition and processing | [ ] |
| IV sensing module | [Enter exact sensor/model] | [ ] | [ ] | [Parameter measured] | [ ] |
| Additional sensor | [Enter exact sensor/model or N/A] | [ ] | [ ] | [Purpose] | [ ] |
| Display / alert device | [Enter exact model or N/A] | [ ] | [ ] | [Purpose] | [ ] |
| Communication module | [Enter exact model or built-in interface] | [ ] | [ ] | [Protocol/link] | [ ] |
| Power supply | [Enter exact rating/model] | [ ] | — | Power | [ ] |

## 2. Pin mapping

| Sensor/module pin | Controller pin | Signal/interface | Notes |
|---|---|---|---|
| [ ] | [ ] | [GPIO/ADC/I2C/UART/SPI/etc.] | [ ] |

## 3. Acquisition specifications

- Controller ADC resolution: [Use the exact controller datasheet]
- ADC input range/reference: [ ]
- Sampling interval/rate: [ ]
- Signal conditioning used: [ ]
- Communication protocol and baud rate/update interval: [ ]
- Power arrangement and protection: [ ]

## 4. Calibration procedure

1. Prepare the safe laboratory test setup and record the conditions.
2. Record sensor readings for the reference/baseline condition.
3. Test at known reference points across the intended operating range.
4. Record raw readings, reference values, converted values, and error.
5. Repeat readings and document variation.
6. Save calibration date, operator, setup, and limitations.

| Reference condition/value | Raw sensor reading | Converted reading | Error | Notes |
|---|---:|---:|---:|---|
| [ ] | [ ] | [ ] | [ ] | [ ] |

## 5. Evidence to attach

- Prototype photograph
- Wiring/pin diagram
- Relevant datasheet links
- Source-code file/commit for sensor acquisition
