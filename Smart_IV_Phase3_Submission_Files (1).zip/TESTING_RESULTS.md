# Prototype Testing Results

> Enter real observations only. If a test has not been run, write “Not yet tested”.

## 1. Test setup

- Date: [ ]
- Prototype revision / Git commit: [ ]
- Hardware configuration: [ ]
- Test fluid or simulation: [ ]
- Reference measurement method: [ ]
- Environmental conditions: [ ]

## 2. Functional test matrix

| Test ID | Scenario | Expected result | Observed result | Pass/Fail/Not tested | Evidence |
|---|---|---|---|---|---|
| T01 | Power-on and startup | [ ] | [ ] | [ ] | [ ] |
| T02 | Normal operating condition | [ ] | [ ] | [ ] | [ ] |
| T03 | Configured warning condition | [ ] | [ ] | [ ] | [ ] |
| T04 | Configured critical condition | [ ] | [ ] | [ ] | [ ] |
| T05 | Movement/noise disturbance | [ ] | [ ] | [ ] | [ ] |
| T06 | Network unavailable (if applicable) | [ ] | [ ] | [ ] | [ ] |
| T07 | Power recovery / restart | [ ] | [ ] | [ ] | [ ] |

## 3. Quantitative measurements

| Metric | Measurement method | Result | Number of trials | Limitations |
|---|---|---:|---:|---|
| Sensor error | Compare against reference | [ ] | [ ] | [ ] |
| Alert response time | Defined event-to-alert interval | [ ] | [ ] | [ ] |
| False-positive rate | FP / (FP + TN), with labeled test cases | [ ] | [ ] | [ ] |
| Miss rate | FN / (TP + FN), with labeled test cases | [ ] | [ ] | [ ] |
| Data update interval | Timestamp successive updates | [ ] | [ ] | [ ] |

Do not report a metric unless the needed reference data and test counts are available.

## 4. User/reviewer feedback

- Reviewer/user group and context: [ ]
- Feedback method or rubric: [ ]
- Main observations: [ ]
- Changes made in response: [ ]
- Consent/privacy considerations, if applicable: [ ]

## 5. Evidence register

| Evidence ID | File/photo/screenshot name | What it demonstrates |
|---|---|---|
| E01 | [ ] | [ ] |
| E02 | [ ] | [ ] |
| E03 | [ ] | [ ] |

## 6. Summary

Completed tests: [ ]
Failed/inconclusive tests: [ ]
Tests still pending: [ ]
Next actions: [ ]
