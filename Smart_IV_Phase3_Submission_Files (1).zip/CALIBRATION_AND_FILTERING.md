# Calibration, Filtering, and Threshold Logic

> Document the algorithm actually present in the code. If a feature is not implemented yet, mark it as planned.

## 1. Sampling and preprocessing

- Sensor: [Exact model]
- Sampling interval: [Measured/configured value]
- Raw signal units: [ ]
- Known noise sources: [e.g., movement, lighting, vibration, wiring]
- Preprocessing implemented: [None / describe]

## 2. Filter

- Filter type: [Moving average / median / EMA / other / none]
- Window length or coefficient: [ ]
- Reason for choosing it: [ ]
- Code file/function: [ ]
- Added processing delay: [Measured value or not measured]

## 3. Decision thresholds

| State | Threshold/condition | Persistence/debounce rule | Action |
|---|---|---|---|
| Normal | [ ] | [ ] | [ ] |
| Warning | [ ] | [ ] | [ ] |
| Critical | [ ] | [ ] | [ ] |

Explain how thresholds were selected and calibrated: [ ]

## 4. False-alert checks

Describe the controlled disturbances tested, such as movement or lighting variation, and the result of each. Do not claim false-positive reduction without test evidence.

| Test condition | Trials | False alerts | Missed alerts | Notes |
|---|---:|---:|---:|---|
| [ ] | [ ] | [ ] | [ ] | [ ] |

## 5. Response-time measurement

Define the start event and end event before measuring. Record repeated trials and report the method used to calculate any summary value.

| Trial | Start timestamp | Alert timestamp | Response time |
|---|---|---|---:|
| 1 | [ ] | [ ] | [ ] |
| 2 | [ ] | [ ] | [ ] |
| 3 | [ ] | [ ] | [ ] |

## 6. Limitations

[Document untested conditions, sensor uncertainty, and known failure modes.]
